package packageG;

public class SuperClass {
	void methodA() {
		System.out.println("Execute Base-Task.");
	}
}
