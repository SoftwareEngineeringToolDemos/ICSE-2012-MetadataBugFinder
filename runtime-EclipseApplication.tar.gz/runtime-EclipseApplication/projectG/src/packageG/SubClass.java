package packageG;

public class SubClass extends SuperClass 
{
	@Override   
	void methodA() {
		super.methodA();
		System.out.println("Execute Sub-Task.");
	}
}  
  