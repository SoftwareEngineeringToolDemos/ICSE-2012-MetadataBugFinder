package packageB;

public @interface XmlType {

	String name();

	String[] propOrder();

}
