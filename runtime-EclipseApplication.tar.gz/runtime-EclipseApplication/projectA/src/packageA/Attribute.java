package packageA;

public @interface Attribute {

	String name();

}
