package packageA;

public class LibraryPackagingElement {
	@Attribute(name = "type")
	public String typeElem;
	@Attribute(name = "url")
	public String url;

	public String getType() {
		return typeElem;
	}

	public void setType(String type) {
		this.typeElem = type;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
}
