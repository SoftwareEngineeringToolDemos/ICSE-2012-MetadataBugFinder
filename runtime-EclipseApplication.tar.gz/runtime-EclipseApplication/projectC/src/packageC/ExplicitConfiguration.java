package packageC;

public class ExplicitConfiguration {
	
	
	@Configuration
	class ExplicitNameConfiguration {
		String env;

		public String getEnv() {
			return env;
		}

		public void setEnv(String env) {
			this.env = env;
		}
	}
	
	
}


