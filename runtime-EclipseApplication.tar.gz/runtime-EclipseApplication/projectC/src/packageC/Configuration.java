package packageC;

public @interface Configuration {

}
